<h1>Readme</h1>
<p>Hi, im Yan Oliveira and this repository was created to control my progress in LINUX, until the LPI Exam Certification</p>
